package oopcw;


public class NormalCustomer extends Customer{
    
    //overidded
    public double getDiscount()
    {
        return 0.05;
    }
}
