/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oopcw;


public class booking_cal { 
    
   private int num_guests;
   private int room_price =0;
   private int food_price = 0;
   private int pool_price =0;
   private int final_pricewithoutDis;
   private double final_pricewithDis;
    private  int num_room  ;
  
   public void setBookingDetails(int guest , int room)
   {
       this.num_guests= guest;
       this.num_room = room;
       
   }
    
   
    public int calPoolprice (String pool){      
    if (pool.equals("yes")){
       pool_price = 500;
}
    else if (pool.equals("no")){
       pool_price = 0;
}
    return pool_price;
    }
    public int calFoodprice (String food){
        
    if (food.equals("yes")){
       food_price = 300;
}
    else if(food.equals("no")) {
      food_price = 0;
}
    return food_price;
    }
    public int calRoomprice (String room_type){
            
        if (room_type.equals("luxury")){
             room_price = num_room*2000;
        }
        else if (room_type.equals("semi luxury")){
             room_price = num_room*1000;
    }
     return room_price;
}
    public void calFinalprice (int num_days){
         final_pricewithoutDis = (room_price*num_days)+(food_price*num_days)+(pool_price*num_days);
        
    }
    
    public double getDiscFinalPrice(double dis)
    {
        double discount = final_pricewithoutDis * dis;
        final_pricewithDis = final_pricewithoutDis-discount;
        return this.final_pricewithDis;
    }
    
}
