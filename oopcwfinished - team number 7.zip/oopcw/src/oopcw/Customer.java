

package oopcw;
import java.sql.*;

public abstract class Customer {
    
    //login page object to obtain the DB connection
    frmUserLogin frm1 = new frmUserLogin();
   
    //customer attributes
   protected String customerID; 
   protected String cusName;
   protected String cusEmail;
   protected  int cusContact;
   protected String customerType;
   protected int cusDeposit;
   //overloaded method to set customer ID only
   public void setCustomerData(String id )
   {
       this.customerID = id; 
   }
   
   public void setCustomerData(String id,String name, String email, int contact,int deposit )
   {
       this.customerID = id;
       this.cusName = name;
       this.cusEmail = email;
       this.cusContact = contact;
       //this.customerType = CustomerType;
       this.cusDeposit = deposit;
   }
   
   public abstract double getDiscount();
   
   public void setCusDetDB() throws SQLException
   {
       //query to enter data to Database
       try (Connection conn = DBConnection.getConnection();
         PreparedStatement  pscusdet = conn.prepareStatement(
             "insert into hotelsystem.Customer values(?,?,?,?,?,?)")){

       
       pscusdet.setString(1,customerID);
       pscusdet.setString(2,cusName);
       pscusdet.setInt(3,cusContact);
       pscusdet.setString(4,cusEmail);
       pscusdet.setString(5,customerType);
       pscusdet.setInt(6,cusDeposit);
       
       int status = pscusdet.executeUpdate();
         
               
              
    }
   }
   
   public void getCusTypeDB() throws SQLException{
       try (Connection conn = DBConnection.getConnection();
         PreparedStatement pscusType = conn.prepareStatement(
             "SELECT * FROM hotelsystem.customer WHERE cusID = ?")) {

        pscusType.setString(1, customerID);
        ResultSet rs = pscusType.executeQuery();

       
        if (rs.next()) {
             this.customerType = rs.getString(5);
        }

    } 
  
}
   
   public String setcustomerType()
   {
       if (this.cusDeposit >= 10000)
       {
           customerType = "Premium";
       }
       
       else
       {
            customerType = "Normal";
       }
       return customerType;
   }
   
   
   public String getCusType()
   {
    return this.customerType;
   } 
    
}
