
package oopcw;


public class PremiumCustomer extends Customer{
    
    //overided
    public double getDiscount()
    {
        return 0.2;
    }
    
}
